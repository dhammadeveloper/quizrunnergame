export type Item={id:number;lane:number;z:number;kind:string;active:boolean};
export const powers=['shield','magnet','boost','double','hint'];
export function spawnRow(id:number):Item[]{const lane=Math.floor(Math.random()*3)-1;const kinds=['block','low','high','gap','moving'];return [{id:id*3,lane,z:-90,kind:kinds[id%5],active:true},{id:id*3+1,lane:lane===1?-1:lane+1,z:-94,kind:id%4===3?powers[Math.floor(id/4)%5]:'coin',active:true},{id:id*3+2,lane:lane===1?-1:lane+1,z:-100,kind:'coin',active:true}];}
export function hits(kind:string,jump:number,slide:number){if(kind==='low'||kind==='gap')return jump<.8;if(kind==='high')return slide<=0;return true;}
export const reward=(type:string)=>type==='match'?150:type==='tf'?50:100;

export type Live={won:boolean;distance:number;lane:number;x:number;jump:number;slide:number;time:number;immune:number;health:number;score:number;coins:number;stars:number;shield:boolean;magnet:number;boost:number;double:number;hint:number;items:Item[];spawn:number;next:number};
export const fresh=():Live=>({won:false,distance:0,lane:0,x:0,jump:0,slide:0,time:0,immune:0,health:3,score:0,coins:0,stars:0,shield:false,magnet:0,boost:0,double:0,hint:1,items:[],spawn:0,next:110});
