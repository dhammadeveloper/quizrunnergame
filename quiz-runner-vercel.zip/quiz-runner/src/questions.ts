export type Question={id:string;sourceRef:string;chapter:number;topic:string;difficulty:'easy'|'medium'|'challenging';type:'mcq'|'tf'|'match';text:string;options:string[];answer:number;explanation:string;hint:string;pairs?:[string,string][]};
// All prompts trace to PT 2 COMP Class 6.docx. Written questions are adapted to selectable answers.
export const questions:Question[]=[
  {
    "id": "pt2-Q1.1",
    "sourceRef": "Q1.1",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Which of the following is a web browser?",
    "options": [
      "Google Chrome",
      "MS Paint",
      "Calculator",
      "Notepad"
    ],
    "answer": 0,
    "explanation": "Google Chrome is a web browser.",
    "hint": "Google Chrome is a web browser."
  },
  {
    "id": "pt2-Q1.2",
    "sourceRef": "Q1.2",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Which of the following is used to send and receive emails?",
    "options": [
      "Paint",
      "Gmail",
      "Calculator",
      "Notepad"
    ],
    "answer": 1,
    "explanation": "Gmail is an email service.",
    "hint": "Gmail is an email service."
  },
  {
    "id": "pt2-Q1.3",
    "sourceRef": "Q1.3",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Which feature is used to add movement to objects in Google Slides?",
    "options": [
      "Animation",
      "Printing",
      "Typing",
      "Saving"
    ],
    "answer": 0,
    "explanation": "Animation adds movement effects to objects.",
    "hint": "Animation adds movement effects to objects."
  },
  {
    "id": "pt2-Q1.4",
    "sourceRef": "Q1.4",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Which option is used to remove unwanted parts of an image in Canva?",
    "options": [
      "Flip",
      "Crop",
      "Rotate",
      "Duplicate"
    ],
    "answer": 1,
    "explanation": "Crop removes unwanted outer parts of an image.",
    "hint": "Crop removes unwanted outer parts of an image."
  },
  {
    "id": "pt2-Q1.5",
    "sourceRef": "Q1.5",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Which symbol is used to represent a start and end in a flowchart?",
    "options": [
      "Rectangle",
      "Diamond",
      "Oval",
      "Arrow"
    ],
    "answer": 2,
    "explanation": "An oval represents the start or end.",
    "hint": "An oval represents the start or end."
  },
  {
    "id": "pt2-Q1.6",
    "sourceRef": "Q1.6",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Which of the following is an online graphic design tool?",
    "options": [
      "Canva",
      "Calculator",
      "Notepad",
      "Gmail"
    ],
    "answer": 0,
    "explanation": "Canva is used to create graphic designs.",
    "hint": "Canva is used to create graphic designs."
  },
  {
    "id": "pt2-Q2.1",
    "sourceRef": "Q2.1",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Machine language is also known as __________ language.",
    "options": [
      "Internet",
      "Algorithm",
      "Templates",
      "Binary",
      "Transition",
      "Bold"
    ],
    "answer": 3,
    "explanation": "Machine language uses binary digits 0 and 1.",
    "hint": "Machine language uses binary digits 0 and 1."
  },
  {
    "id": "pt2-Q2.2",
    "sourceRef": "Q2.2",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "The __________ connects computers around the world.",
    "options": [
      "Internet",
      "Algorithm",
      "Templates",
      "Binary",
      "Transition",
      "Bold"
    ],
    "answer": 0,
    "explanation": "The Internet connects computer networks worldwide.",
    "hint": "The Internet connects computer networks worldwide."
  },
  {
    "id": "pt2-Q2.3",
    "sourceRef": "Q2.3",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "A __________ effect is applied when moving from one slide to another.",
    "options": [
      "Internet",
      "Algorithm",
      "Templates",
      "Binary",
      "Transition",
      "Bold"
    ],
    "answer": 4,
    "explanation": "A transition is an effect between slides.",
    "hint": "A transition is an effect between slides."
  },
  {
    "id": "pt2-Q2.4",
    "sourceRef": "Q2.4",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "The __________ option is used to make text bolder.",
    "options": [
      "Internet",
      "Algorithm",
      "Templates",
      "Binary",
      "Transition",
      "Bold"
    ],
    "answer": 5,
    "explanation": "Bold makes text thicker and darker.",
    "hint": "Bold makes text thicker and darker."
  },
  {
    "id": "pt2-Q2.5",
    "sourceRef": "Q2.5",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "An __________ is a step-by-step procedure to solve a problem.",
    "options": [
      "Internet",
      "Algorithm",
      "Templates",
      "Binary",
      "Transition",
      "Bold"
    ],
    "answer": 1,
    "explanation": "An algorithm gives ordered steps to solve a problem.",
    "hint": "An algorithm gives ordered steps to solve a problem."
  },
  {
    "id": "pt2-Q2.6",
    "sourceRef": "Q2.6",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "mcq",
    "text": "Canva provides ready-made designs called __________.",
    "options": [
      "Internet",
      "Algorithm",
      "Templates",
      "Binary",
      "Transition",
      "Bold"
    ],
    "answer": 2,
    "explanation": "Templates are ready-made designs you can edit.",
    "hint": "Templates are ready-made designs you can edit."
  },
  {
    "id": "pt2-Q3.1",
    "sourceRef": "Q3.1",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "tf",
    "text": "A laptop is a portable computer.",
    "options": [
      "True",
      "False"
    ],
    "answer": 0,
    "explanation": "A laptop can be carried easily.",
    "hint": "A laptop can be carried easily."
  },
  {
    "id": "pt2-Q3.2",
    "sourceRef": "Q3.2",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "tf",
    "text": "We should share our passwords with everyone.",
    "options": [
      "True",
      "False"
    ],
    "answer": 1,
    "explanation": "Keep your password private.",
    "hint": "Keep your password private."
  },
  {
    "id": "pt2-Q3.3",
    "sourceRef": "Q3.3",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "tf",
    "text": "Google Slides is used to create presentations.",
    "options": [
      "True",
      "False"
    ],
    "answer": 0,
    "explanation": "Google Slides creates slide presentations.",
    "hint": "Google Slides creates slide presentations."
  },
  {
    "id": "pt2-Q3.4",
    "sourceRef": "Q3.4",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "tf",
    "text": "Google Sheets cannot store numbers.",
    "options": [
      "True",
      "False"
    ],
    "answer": 1,
    "explanation": "Google Sheets can store text and numbers.",
    "hint": "Google Sheets can store text and numbers."
  },
  {
    "id": "pt2-Q3.5",
    "sourceRef": "Q3.5",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "tf",
    "text": "A flowchart uses symbols to show steps.",
    "options": [
      "True",
      "False"
    ],
    "answer": 0,
    "explanation": "Flowchart symbols show steps and their order.",
    "hint": "Flowchart symbols show steps and their order."
  },
  {
    "id": "pt2-Q3.6",
    "sourceRef": "Q3.6",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "tf",
    "text": "Canva can be used to create posters.",
    "options": [
      "True",
      "False"
    ],
    "answer": 0,
    "explanation": "Canva provides tools and templates for posters.",
    "hint": "Canva provides tools and templates for posters."
  },
  {
    "id": "pt2-Q4.1-3",
    "sourceRef": "Q4.1-3",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "match",
    "text": "Match the following.",
    "options": [],
    "answer": 0,
    "explanation": "CTRL+C: Copy. CTRL+X: Cut. CTRL+V: Paste",
    "hint": "CTRL+C: Copy. CTRL+X: Cut. CTRL+V: Paste",
    "pairs": [
      [
        "CTRL+C",
        "Copy"
      ],
      [
        "CTRL+X",
        "Cut"
      ],
      [
        "CTRL+V",
        "Paste"
      ]
    ]
  },
  {
    "id": "pt2-Q4.4-6",
    "sourceRef": "Q4.4-6",
    "chapter": 1,
    "topic": "PT-II question paper",
    "difficulty": "easy",
    "type": "match",
    "text": "Match the following.",
    "options": [],
    "answer": 0,
    "explanation": "Google Sheets: Spreadsheet application. Flowchart: Visual representation of steps. Email: Electronic message",
    "hint": "Google Sheets: Spreadsheet application. Flowchart: Visual representation of steps. Email: Electronic message",
    "pairs": [
      [
        "Google Sheets",
        "Spreadsheet application"
      ],
      [
        "Flowchart",
        "Visual representation of steps"
      ],
      [
        "Email",
        "Electronic message"
      ]
    ]
  },
  {
    "id": "pt2-Q5.1",
    "sourceRef": "Q5.1",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is antivirus software?",
    "options": [
      "Software that detects and helps remove computer viruses",
      "A tool only for drawing",
      "A type of keyboard",
      "A slide effect"
    ],
    "answer": 0,
    "explanation": "Antivirus software helps detect, block and remove malicious software.",
    "hint": "Antivirus software helps detect, block and remove malicious software."
  },
  {
    "id": "pt2-Q5.2",
    "sourceRef": "Q5.2",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Name any one method of online payment.",
    "options": [
      "UPI",
      "Cash handed to a shopkeeper",
      "A handwritten letter",
      "A printed poster"
    ],
    "answer": 0,
    "explanation": "UPI is one method of online payment.",
    "hint": "UPI is one method of online payment."
  },
  {
    "id": "pt2-Q5.3",
    "sourceRef": "Q5.3",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is an animation?",
    "options": [
      "A movement effect applied to an object on a slide",
      "A move from one slide to another",
      "A printed copy",
      "A password"
    ],
    "answer": 0,
    "explanation": "Animation adds movement or other visual effects to an object.",
    "hint": "Animation adds movement or other visual effects to an object."
  },
  {
    "id": "pt2-Q5.4",
    "sourceRef": "Q5.4",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is Canva?",
    "options": [
      "An online graphic design tool",
      "A spreadsheet cell",
      "A programming language",
      "A computer virus"
    ],
    "answer": 0,
    "explanation": "Canva is an online tool used to create designs such as posters and presentations.",
    "hint": "Canva is an online tool used to create designs such as posters and presentations."
  },
  {
    "id": "pt2-Q5.5",
    "sourceRef": "Q5.5",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is the Internet?",
    "options": [
      "A worldwide network of connected computer networks",
      "A drawing program",
      "A keyboard",
      "A single spreadsheet"
    ],
    "answer": 0,
    "explanation": "The Internet connects computers and networks around the world.",
    "hint": "The Internet connects computers and networks around the world."
  },
  {
    "id": "pt2-Q5.6",
    "sourceRef": "Q5.6",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is meant by e-commerce?",
    "options": [
      "Buying and selling goods or services online",
      "Drawing a picture",
      "Typing offline",
      "Changing a font"
    ],
    "answer": 0,
    "explanation": "E-commerce means buying and selling goods or services over the Internet.",
    "hint": "E-commerce means buying and selling goods or services over the Internet."
  },
  {
    "id": "pt2-Q6.1",
    "sourceRef": "Q6.1",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "How do you start a Google Sheet? Choose the correct steps.",
    "options": [
      "Open Google Sheets in a browser, sign in if needed, and choose Blank",
      "Open Paint and draw cells",
      "Open Gmail and delete a message",
      "Open Canva and crop an image"
    ],
    "answer": 0,
    "explanation": "Open Google Sheets, sign in to your Google account if needed, and select Blank to create a spreadsheet.",
    "hint": "Open Google Sheets, sign in to your Google account if needed, and select Blank to create a spreadsheet."
  },
  {
    "id": "pt2-Q6.2",
    "sourceRef": "Q6.2",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is the difference between flipping and cropping?",
    "options": [
      "Flipping mirrors an image; cropping removes unwanted parts",
      "Flipping removes parts; cropping mirrors an image",
      "Both only change the colour",
      "Both only add text"
    ],
    "answer": 0,
    "explanation": "Flipping reverses an image horizontally or vertically. Cropping removes unwanted outer parts.",
    "hint": "Flipping reverses an image horizontally or vertically. Cropping removes unwanted outer parts."
  },
  {
    "id": "pt2-Q6.3",
    "sourceRef": "Q6.3",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Which steps create a poster in Canva?",
    "options": [
      "Choose Poster → choose a template → edit text and images → download",
      "Open Calculator → add numbers → shut down",
      "Copy a cell → paste a cell → delete a row",
      "Open a browser → delete all files"
    ],
    "answer": 0,
    "explanation": "In Canva, choose a poster design, select a template, edit the text and images, then download your poster.",
    "hint": "In Canva, choose a poster design, select a template, edit the text and images, then download your poster."
  },
  {
    "id": "pt2-Q6.4",
    "sourceRef": "Q6.4",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Which answer explains two popular Internet services?",
    "options": [
      "Email sends electronic messages; video conferencing supports live audio and video meetings",
      "Email crops images; video conferencing prints documents",
      "Email charges a laptop; video conferencing stores electricity",
      "Email makes a keyboard; video conferencing cuts paper"
    ],
    "answer": 0,
    "explanation": "Email sends and receives electronic messages. Video conferencing lets people meet using live audio and video.",
    "hint": "Email sends and receives electronic messages. Video conferencing lets people meet using live audio and video."
  },
  {
    "id": "pt2-Q6.5",
    "sourceRef": "Q6.5",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Which answer correctly explains elements of a Google spreadsheet?",
    "options": [
      "Rows are horizontal, columns are vertical, and their intersections are cells",
      "Rows are vertical and columns are horizontal",
      "A cell is the same as the entire spreadsheet",
      "Column letters show slide transitions"
    ],
    "answer": 0,
    "explanation": "A spreadsheet contains numbered horizontal rows, lettered vertical columns and cells. The formula bar shows or edits the selected cell’s contents; sheet tabs switch between sheets.",
    "hint": "A spreadsheet contains numbered horizontal rows, lettered vertical columns and cells. The formula bar shows or edits the selected cell’s contents; sheet tabs switch between sheets."
  },
  {
    "id": "pt2-Q6.6",
    "sourceRef": "Q6.6",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is a flowchart? Which answer also explains one symbol?",
    "options": [
      "A diagram showing steps; an oval marks the start or end",
      "A spreadsheet; an oval stores a password",
      "An email; an oval sends a message",
      "A poster; an oval always means a decision"
    ],
    "answer": 0,
    "explanation": "A flowchart visually shows steps using symbols and arrows. An oval is used for the start or end.",
    "hint": "A flowchart visually shows steps using symbols and arrows. An oval is used for the start or end."
  },
  {
    "id": "pt2-Q7.1",
    "sourceRef": "Q7.1",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Which answer correctly describes types of computers with examples?",
    "options": [
      "Supercomputer: weather calculations; mainframe: bank transactions; minicomputer: a mid-sized multi-user system; microcomputer: desktop or laptop",
      "Supercomputer: pocket mouse; mainframe: paper; minicomputer: pencil; microcomputer: chair",
      "All computers are only laptops",
      "A desktop is a type of printer"
    ],
    "answer": 0,
    "explanation": "Supercomputers handle complex calculations. Mainframes handle large volumes of transactions. Minicomputers are traditionally mid-sized multi-user systems. Microcomputers include desktops and laptops.",
    "hint": "Supercomputers handle complex calculations. Mainframes handle large volumes of transactions. Minicomputers are traditionally mid-sized multi-user systems. Microcomputers include desktops and laptops."
  },
  {
    "id": "pt2-Q7.2",
    "sourceRef": "Q7.2",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is an algorithm? Which algorithm adds two numbers?",
    "options": [
      "Ordered steps: Start → input A and B → calculate Sum = A + B → display Sum → Stop",
      "Start → input A and B → subtract B from A → Stop",
      "Start → print A without adding → Stop",
      "Start → delete both numbers → Stop"
    ],
    "answer": 0,
    "explanation": "An algorithm is a step-by-step procedure. To add two numbers, input them, calculate their sum, display the sum, then stop.",
    "hint": "An algorithm is a step-by-step procedure. To add two numbers, input them, calculate their sum, display the sum, then stop."
  },
  {
    "id": "pt2-Q7.3",
    "sourceRef": "Q7.3",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "What is Canva? Which answer correctly explains its components?",
    "options": [
      "A graphic design tool: templates give layouts, elements add shapes and graphics, text adds words, uploads add your files, and the canvas is the design area",
      "An email service: Inbox, Sent and Spam",
      "A calculator: add, subtract and divide",
      "A spreadsheet: only rows and columns"
    ],
    "answer": 0,
    "explanation": "Canva is an online graphic design tool. Templates provide ready-made designs; Elements provides graphics and shapes; Text adds words; Uploads adds files; the canvas is where you arrange the design.",
    "hint": "Canva is an online graphic design tool. Templates provide ready-made designs; Elements provides graphics and shapes; Text adds words; Uploads adds files; the canvas is where you arrange the design."
  },
  {
    "id": "pt2-Q8.1a",
    "sourceRef": "Q8.1a",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Rahul receives an online-game message asking for his password to win a free gift. Should he share his password?",
    "options": [
      "No, he should keep it private",
      "Yes, to get the gift",
      "Yes, with every player",
      "Yes, if the message is colourful"
    ],
    "answer": 0,
    "explanation": "Rahul should not share his password. The message may be trying to steal his account details.",
    "hint": "Rahul should not share his password. The message may be trying to steal his account details."
  },
  {
    "id": "pt2-Q8.1b",
    "sourceRef": "Q8.1b",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Whom should Rahul inform about the message asking for his password?",
    "options": [
      "A trusted adult, such as a parent or teacher",
      "An unknown online player",
      "The person asking for his password",
      "Nobody"
    ],
    "answer": 0,
    "explanation": "Rahul should inform a trusted adult such as a parent or teacher.",
    "hint": "Rahul should inform a trusted adult such as a parent or teacher."
  },
  {
    "id": "pt2-Q8.1c",
    "sourceRef": "Q8.1c",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Write one rule for creating a strong password. Choose the correct rule.",
    "options": [
      "Use a long, unique password that is difficult to guess",
      "Use 123456 for every account",
      "Use only your first name",
      "Share the password publicly"
    ],
    "answer": 0,
    "explanation": "Use a long, unique password; avoid easily guessed information such as your name.",
    "hint": "Use a long, unique password; avoid easily guessed information such as your name."
  },
  {
    "id": "pt2-Q8.2a",
    "sourceRef": "Q8.2a",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Aman uses a desktop and his sister uses a laptop. Which computer can be carried more easily?",
    "options": [
      "Laptop",
      "Desktop with separate monitor",
      "Both are always equally portable",
      "Neither"
    ],
    "answer": 0,
    "explanation": "A laptop has a built-in screen and keyboard and is designed for portability.",
    "hint": "A laptop has a built-in screen and keyboard and is designed for portability."
  },
  {
    "id": "pt2-Q8.2b",
    "sourceRef": "Q8.2b",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Which computer usually needs a continuous external power supply?",
    "options": [
      "Desktop",
      "Laptop running on its charged battery",
      "Neither computer ever needs power",
      "Only the keyboard"
    ],
    "answer": 0,
    "explanation": "A desktop usually needs an external power supply. A laptop can run on its charged battery.",
    "hint": "A desktop usually needs an external power supply. A laptop can run on its charged battery."
  },
  {
    "id": "pt2-Q8.2c",
    "sourceRef": "Q8.2c",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Write one task that both a desktop and a laptop can perform.",
    "options": [
      "Creating a document",
      "Cooking food without extra equipment",
      "Washing clothes",
      "Printing without a printer"
    ],
    "answer": 0,
    "explanation": "Both a desktop and a laptop can be used to create and edit documents.",
    "hint": "Both a desktop and a laptop can be used to create and edit documents."
  },
  {
    "id": "pt2-Q8.3a",
    "sourceRef": "Q8.3a",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Sara’s school name is in A1. She wants it in A5 while keeping it in A1. Which cell should she select to copy it?",
    "options": [
      "A1",
      "A5",
      "B1",
      "B5"
    ],
    "answer": 0,
    "explanation": "Select A1 because it contains the school name to copy.",
    "hint": "Select A1 because it contains the school name to copy."
  },
  {
    "id": "pt2-Q8.3b",
    "sourceRef": "Q8.3b",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "Which command should Sara use to keep the school name in A1 and place a copy in A5?",
    "options": [
      "Copy",
      "Cut",
      "Delete",
      "Clear"
    ],
    "answer": 0,
    "explanation": "Copy keeps the original content in A1. Cut would move it.",
    "hint": "Copy keeps the original content in A1. Cut would move it."
  },
  {
    "id": "pt2-Q8.3c",
    "sourceRef": "Q8.3c",
    "chapter": 2,
    "topic": "PT-II question paper",
    "difficulty": "medium",
    "type": "mcq",
    "text": "In which cell should Sara paste the copied school name?",
    "options": [
      "A5",
      "A1",
      "B5",
      "C1"
    ],
    "answer": 0,
    "explanation": "Paste into A5, the destination specified in the question.",
    "hint": "Paste into A5, the destination specified in the question."
  }
];

export const shuffle=<T,>(a:T[])=>{const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;};
export function runQuestions(chapter:number){return shuffle(questions.filter(q=>q.chapter===chapter)).slice(0,10);}
